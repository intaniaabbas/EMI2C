document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    window.location.href = "selection.html"; // Redirect to the selection page

    e.preventDefault();

});
