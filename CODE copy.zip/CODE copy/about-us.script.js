// Add an event listener to the logo to redirect to the home page when clicked
document.querySelector('.logo-container').addEventListener('click', function() {
    window.location.href = "home.html"; // Redirect to the home page
});
